library(testthat)
library(OmicsPLS)

test_check("OmicsPLS")

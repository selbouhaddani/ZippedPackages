Sys.setenv(R_TESTS="")
library(testthat)
library(OmicsPLS)

test_check("OmicsPLS")
